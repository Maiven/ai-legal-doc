# AI Legal Doc Generator

Deploy on Vercel with your OpenAI API key.
