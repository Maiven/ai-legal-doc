import { NextRequest, NextResponse } from 'next/server';
import PDFDocument from 'pdfkit';
import { Readable } from 'stream';

export async function POST(req: NextRequest) {
  const { content } = await req.json();

  const doc = new PDFDocument();
  const stream = docToStream(doc);

  doc.font('Helvetica').fontSize(12).text(content, {
    width: 410,
    align: 'left',
  });

  doc.end();

  return new NextResponse(stream as any, {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': 'attachment; filename=generated.pdf',
    },
  });
}

function docToStream(doc) {
  const stream = new Readable({ read() {} });
  doc.on('data', (chunk) => stream.push(chunk));
  doc.on('end', () => stream.push(null));
  return stream;
}
